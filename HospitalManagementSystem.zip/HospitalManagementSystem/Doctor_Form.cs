﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HospitalManagementSystem
{
    public partial class Doctor_Form : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\hp\Documents\Hospital Managemnet System Database.mdf"";Integrated Security=True;Connect Timeout=30");
        public Doctor_Form()
        {
            InitializeComponent();
        }

        private void Doctor_Form_Load(object sender, EventArgs e)
        {

        }

        private void cmdHome_Click(object sender, EventArgs e)
        {
            frmHomePage HP = new frmHomePage();
            HP.Show();
            this.Hide();
        }

        private void cmdAdd_Click(object sender, EventArgs e)
        {

        }
    }
}
